package com.visionbot.services
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.os.Handler
import android.os.Looper
class AutoClickService:AccessibilityService(){ companion object{var instance:AutoClickService?=null};private val h=Handler(Looper.getMainLooper());override fun onServiceConnected(){instance=this};override fun onAccessibilityEvent(e:AccessibilityEvent?){};override fun onInterrupt(){};fun tap(x:Float,y:Float,d:Long=15){val p=Path().apply{moveTo(x,y)};dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p,0,d)).build(),null,null)};override fun onDestroy(){instance=null;h.removeCallbacksAndMessages(null);super.onDestroy()}}
