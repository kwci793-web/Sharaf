package com.visionbot.utils
object Constants { const val ROUND_MS=30_000L; const val DEFAULT_DELAY=50L; const val MIN_DELAY=15L; const val MAX_DELAY=150L; const val TARGET_SIZE=120; const val CELL_SIZE=48; const val MATCH_THRESHOLD=0.91f; const val MAX_REPEAT=3 }
