package com.visionbot.services

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.display.*
import android.media.*
import android.media.projection.MediaProjectionManager
import android.os.*
import com.visionbot.utils.*
import com.visionbot.vision.VisionEngine
import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureService : Service() {
    companion object { const val EXTRA_RESULT = "result"; const val EXTRA_DATA = "data"; var running = false }
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val engine = VisionEngine()
    private val analyzing = AtomicBoolean(false)
    private var started = 0L
    private var frame = 0L

    override fun onBind(intent: Intent?) = null

    override fun onStartCommand(intent: Intent?, flags: Int, id: Int): Int {
        if (intent == null || reader != null) return START_NOT_STICKY
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val data = intent.getParcelableExtra<Intent>(EXTRA_DATA) ?: return START_NOT_STICKY
        val projection = manager.getMediaProjection(intent.getIntExtra(EXTRA_RESULT, 0), data) ?: return START_NOT_STICKY
        val dm = resources.displayMetrics
        reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        display = projection.createVirtualDisplay("VisionBot", dm.widthPixels, dm.heightPixels, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
        started = SystemClock.elapsedRealtime(); running = true
        startForeground(11, notification())
        reader!!.setOnImageAvailableListener({ source ->
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            if (SystemClock.elapsedRealtime() - started >= Constants.ROUND_MS) { image.close(); stopSelf(); return@setOnImageAvailableListener }
            val bitmap = try {
                Bitmap.createBitmap(dm.widthPixels, dm.heightPixels, Bitmap.Config.ARGB_8888).also { it.copyPixelsFromBuffer(image.planes[0].buffer) }
            } finally { image.close() }
            if (analyzing.compareAndSet(false, true)) scope.launch { analyze(bitmap, ++frame) }
        }, Handler(Looper.getMainLooper()))
        return START_NOT_STICKY
    }

    private suspend fun analyze(bitmap: Bitmap, frameId: Long) {
        try {
            val settings = SettingsStore(this)
            val grid = settings.gridRect ?: return
            val match = engine.find(bitmap, grid, frameId) ?: return
            val service = AutoClickService.instance ?: return
            withContext(Dispatchers.Main.immediate) {
                service.tap(match.first.x, match.first.y)
                service.tap(match.second.x, match.second.y)
            }
            delay(settings.delay)
        } finally { analyzing.set(false) }
    }

    private fun notification() = Notification.Builder(this, "vision").setContentTitle("VisionBot يعمل").setSmallIcon(android.R.drawable.ic_menu_view).build()
    override fun onCreate() { super.onCreate(); (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel("vision", "VisionBot", NotificationManager.IMPORTANCE_LOW)) }
    override fun onDestroy() { running = false; scope.cancel(); reader?.close(); display?.release(); reader = null; display = null; super.onDestroy() }
}
