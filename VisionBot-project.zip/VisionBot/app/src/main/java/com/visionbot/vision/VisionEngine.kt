package com.visionbot.vision

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PointF
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.sqrt

data class Match(val first: PointF, val second: PointF, val score: Float)

class VisionEngine {
    private var lastPair: Pair<Int, Int>? = null
    private var lastFrame = -1L

    fun find(bitmap: Bitmap, grid: Rect, frameId: Long): Match? {
        if (grid.width() < 20 || grid.height() < 20) return null
        val cols = 4; val rows = 5
        val cw = grid.width().toFloat() / cols; val ch = grid.height().toFloat() / rows
        val cells = ArrayList<Cell>(20)
        for (r in 0 until rows) for (c in 0 until cols) {
            val rect = Rect((grid.left + c * cw).toInt(), (grid.top + r * ch).toInt(), (grid.left + (c + 1) * cw).toInt(), (grid.top + (r + 1) * ch).toInt())
            cells += Cell(r * cols + c, rect, descriptor(bitmap, rect))
        }
        var best: Match? = null; var bestScore = 0f
        for (i in 0 until cells.size - 1) for (j in i + 1 until cells.size) {
            val score = compare(cells[i].features, cells[j].features)
            val key = cells[i].index to cells[j].index
            if (score >= 0.89f && score > bestScore && !(key == lastPair && frameId - lastFrame < 4)) {
                bestScore = score
                best = Match(center(cells[i].rect), center(cells[j].rect), score)
            }
        }
        if (best != null) { lastPair = cellIndex(best.first, grid, cw, ch) to cellIndex(best.second, grid, cw, ch); lastFrame = frameId }
        return best
    }

    private data class Cell(val index: Int, val rect: Rect, val features: FloatArray)

    private fun descriptor(bitmap: Bitmap, source: Rect): FloatArray {
        val out = FloatArray(136); val mx = (source.width() * .12f).toInt(); val my = (source.height() * .12f).toInt()
        val r = Rect((source.left + mx).coerceIn(0, bitmap.width - 1), (source.top + my).coerceIn(0, bitmap.height - 1), (source.right - mx).coerceIn(1, bitmap.width), (source.bottom - my).coerceIn(1, bitmap.height))
        var p = 0; var mean = 0f
        for (y in 0 until 8) for (x in 0 until 8) { val c = sample(bitmap, r, x, y, 8, 8); val l = lum(c); out[p++] = l; mean += l }
        mean /= 64f; for (i in 0 until 64) out[i] -= mean
        for (y in 0 until 8) for (x in 0 until 8) { val c = sample(bitmap, r, x, y, 8, 8); out[p++] = (Color.red(c) - Color.blue(c)) / 255f; out[p++] = (Color.green(c) - Color.blue(c)) / 255f }
        var rr = 0f; var gg = 0f; var bb = 0f; val bins = FloatArray(16)
        for (y in 0 until 4) for (x in 0 until 4) { val c = sample(bitmap, r, x, y, 4, 4); val cr = Color.red(c) / 255f; val cg = Color.green(c) / 255f; val cb = Color.blue(c) / 255f; rr += cr; gg += cg; bb += cb; bins[((cr + 2 * cg + 3 * cb) * 5.3f).toInt().coerceIn(0, 15)]++ }
        out[p++] = rr / 16f; out[p++] = gg / 16f; out[p++] = bb / 16f; for (b in bins) out[p++] = b / 16f
        return out
    }

    private fun sample(b: Bitmap, r: Rect, x: Int, y: Int, w: Int, h: Int): Int = b.getPixel((r.left + (x + .5f) * r.width() / w).toInt().coerceIn(0, b.width - 1), (r.top + (y + .5f) * r.height() / h).toInt().coerceIn(0, b.height - 1))
    private fun lum(c: Int) = (Color.red(c) * .299f + Color.green(c) * .587f + Color.blue(c) * .114f) / 255f
    private fun compare(a: FloatArray, b: FloatArray): Float { var dot = 0f; var aa = 0f; var bb = 0f; for (i in 0 until 64) { dot += a[i] * b[i]; aa += a[i] * a[i]; bb += b[i] * b[i] }; val shape = ((dot / sqrt((aa * bb).coerceAtLeast(.000001f))) + 1f) / 2f; var d = 0f; for (i in 64 until a.size) d += abs(a[i] - b[i]); return shape * .78f + (1f - d / (a.size - 64) * 1.8f).coerceIn(0f, 1f) * .22f }
    private fun center(r: Rect) = PointF((r.left + r.right) / 2f, (r.top + r.bottom) / 2f)
    private fun cellIndex(p: PointF, g: Rect, cw: Float, ch: Float): Int = (((p.y - g.top) / ch).toInt().coerceIn(0, 4) * 4 + ((p.x - g.left) / cw).toInt().coerceIn(0, 3))
}
